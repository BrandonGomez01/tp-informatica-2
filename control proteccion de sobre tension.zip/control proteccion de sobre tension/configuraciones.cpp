/*No se usa este archivo */
/*cargo el estado actual de los cables en 1, que significa que esta bien hasta el momento*/
cables okay
/*  se activa la proteccion se establece como 1800 volts */
tension_limite 1800
/* Inventamos una tension actual medida */
tension 60
/*Avisos dira que esta todo bien */
